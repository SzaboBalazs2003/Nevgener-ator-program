﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Névgenerátor_program
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<String> csaladiNevek = new ObservableCollection<string>();
        ObservableCollection<String> utoNevek = new ObservableCollection<string>();
        static ObservableCollection<String> csaladiNevekOriginal = new ObservableCollection<string>();
        static ObservableCollection<String> utoNevekOriginal = new ObservableCollection<string>();
        Random r;
        public MainWindow()
        {
            InitializeComponent();
            r = new Random();
        }

        private void btnBetoltCsaladneveket_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true) 
            {
                
                foreach (var item in File.ReadAllLines(ofd.FileName).ToList())
                {
                    csaladiNevek.Add(item);
                    csaladiNevekOriginal.Add(item);
                }
                lbCsaladnevek.ItemsSource = csaladiNevek;
            }
            
        }

        private void btnBetoltUtoneveket_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                
                foreach (var item in File.ReadAllLines(ofd.FileName).ToList())
                {
                    utoNevek.Add(item);
                    utoNevekOriginal.Add(item);
                }
                lbUtonevek.ItemsSource = utoNevek;
            }
            
        }

        private void btnGeneral_Click(object sender, RoutedEventArgs e)
        {
            if (lbCsaladnevek.Items.Count == 0)
            {
                MessageBox.Show("Nincs több név");
                btnGeneral.IsHitTestVisible = false;
            }
            if (rdoEgy.IsChecked == true && rdoKetto.IsChecked == false)
            {
                for (int i = 0; i < sliNevekszama.Value; i++)
                {
                    int kivVezIndex = r.Next(lbCsaladnevek.Items.Count);
                    int kivUtoIndex = r.Next(lbUtonevek.Items.Count);
                    lbKesznevek.Items.Add($"{csaladiNevek[kivVezIndex]} {utoNevek[kivUtoIndex]}");
                    csaladiNevek.RemoveAt(kivVezIndex);
                    utoNevek.RemoveAt(kivUtoIndex);
                }
            }
            else if (rdoKetto.IsChecked == true && rdoEgy.IsChecked == false)
            {
                for (int i = 0; i < sliNevekszama.Value; i++)
                {
                    int kivVezIndex = r.Next(lbCsaladnevek.Items.Count);
                    int kivUtoIndex = r.Next(lbUtonevek.Items.Count);
                    string uto1 = utoNevek[kivUtoIndex];
                    utoNevek.RemoveAt(kivUtoIndex);
                    int kivUtoIndex2 = r.Next(lbUtonevek.Items.Count);
                    string uto2 = utoNevek[kivUtoIndex2];
                    utoNevek.RemoveAt(kivUtoIndex2);
                    lbKesznevek.Items.Add($"{csaladiNevek[kivVezIndex]} {uto1} {uto2}");
                    csaladiNevek.RemoveAt(kivVezIndex);
                }
            }
            stbRendezes.Content = "";
            ListaVegereUgras();
        }

        private void btnTorles_Click(object sender, RoutedEventArgs e)
        {
            lbKesznevek.Items.Clear();
            csaladiNevek.Clear();
            utoNevek.Clear();
            
            foreach (var item in csaladiNevekOriginal)
            {
                csaladiNevek.Add(item);
            }
            foreach (var item in utoNevekOriginal)
            {
                utoNevek.Add(item);
            }

            lbCsaladnevek.ItemsSource = csaladiNevek;
            lbUtonevek.ItemsSource = utoNevek;
            lbCsaladnevek.Items.Refresh();
            lbUtonevek.Items.Refresh();


        }

        private void btnRendezes_Click(object sender, RoutedEventArgs e)
        {
            lbKesznevek.Items.SortDescriptions.Add(new SortDescription("", ListSortDirection.Ascending));
            stbRendezes.Content = "A lista rendezve lett!";
            ListaVegereUgras();
        }

        private void btnMentes_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.AddExtension = true;
            sfd.DefaultExt = "txt";
            sfd.Filter = "A szöveges fájl (*.txt)|*.txt|CSV fájl (*.csv)|*.csv|Összes fájl (*.*)|*.*";
            sfd.Title = "Adja meg a névsor nevét!";
            if (sfd.ShowDialog() == true)
            {
                try
                {
                    StreamWriter sw = new StreamWriter(sfd.FileName);
                    foreach (var item in lbKesznevek.Items)
                    {
                        sw.WriteLine(item);
                    }
                    sw.Flush();
                    sw.Close();
                    MessageBox.Show("Sikeres mentés");
                }
                catch (Exception)
                {
                    MessageBox.Show("Hiba történt!");
                }
            }
            
        }
        private void ListaVegereUgras()
        {
            lbKesznevek.Items.MoveCurrentToLast();
            lbKesznevek.ScrollIntoView(lbKesznevek.Items.CurrentItem);
        }
    }
}
